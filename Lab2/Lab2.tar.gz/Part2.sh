awk -f Part2_1.awk gradebook.csv
echo
awk -f Part2_2.awk gradebook.csv
echo
awk -f Part2_3.awk gradebook.csv
echo
